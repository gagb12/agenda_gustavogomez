<?php
 require('conexion.php');

 	$con= new conexionBD;


 	echo $con->userSession();



 ?>
