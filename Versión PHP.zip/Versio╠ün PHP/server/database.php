<?php
	require('./conexion.php');
	$con = new conexionBD(); //Iniciar el objeto conexionBD
	$response['msg'] = $con->verifyConexion();//Iniciar la función verifyConexion
	return $response['msg']; //Devolver resultado

 ?>
